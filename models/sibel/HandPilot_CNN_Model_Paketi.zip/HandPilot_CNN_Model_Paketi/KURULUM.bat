@echo off
chcp 65001 >nul
title HandPilot Yerel Kurulum
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" python -m venv .venv
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements-local.txt
if errorlevel 1 (
  echo Kurulum basarisiz.
  pause
  exit /b 1
)
echo Kurulum tamamlandi. CANLI_TEST.bat ile kamerayi baslatabilirsiniz.
pause
