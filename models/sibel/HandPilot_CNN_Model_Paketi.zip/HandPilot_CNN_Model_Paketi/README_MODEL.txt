HANDPILOT CNN MODEL PAKETI
==========================

Model: handpilot_mobilenet_v3_small.keras
Mimari: MobileNetV3Small
Girdi: MediaPipe ile tespit edilmis el ROI, RGB, 160x160, %30 padding
Sinif sirasi: 0=fren, 1=gaz, 2=sag, 3=sol

KUTUPHANE SURUMLERI
TensorFlow 2.21.0
Keras 3.13.2
MediaPipe 0.10.32

TEST SONUCLARI
Ornek: 1558
Accuracy: %98.7163
Balanced accuracy: %98.8317
Macro F1: %98.6033
Gaz -> fren: 0
Fren -> gaz: 0

MODELI YUKLEME
from tensorflow import keras
model = keras.models.load_model('handpilot_mobilenet_v3_small.keras')

ONEMLI
Canli entegrasyonda egitimdeki ayni MediaPipe el kirpma adimlari uygulanmalidir.
El tespit edilemezse veya guven dusukse arac guvenli bicimde durdurulmalidir.
Modelde diger/bilinmeyen hareket ve ayri geri sinifi bulunmaz.
Ayrintili bilgiler model_info.json ve upload_status.json dosyalarindadir.

YEREL CANLI KAMERA
1. Ilk kurulum icin KURULUM.bat dosyasini calistirin.
2. Lenovo LOQ 15IRX9'un sag kenarindaki kamera e-shutter anahtarini acin.
   Kirmizi isaret gorunmemelidir.
3. CANLI_TEST.bat dosyasini calistirin.
4. Q veya Esc ile cikabilir, S ile goruntu kaydedebilirsiniz.

Yerel ortam .venv klasorundedir. Paketler requirements-local.txt dosyasinda
sabitlenmistir. Colab tarayicisinin fiziksel kamerayi acamamasindan etkilenmez.
