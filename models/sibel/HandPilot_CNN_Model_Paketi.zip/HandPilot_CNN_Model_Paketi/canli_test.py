from __future__ import annotations

import argparse
import os
import sys
import time
import urllib.request
from collections import deque
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageOps

CLASSES = ("fren", "gaz", "sag", "sol")
TITLES = {"fren": "FREN (DUR)", "gaz": "GAZ (ILERI)", "sag": "SAG", "sol": "SOL"}
COLORS = {"fren": (40, 40, 230), "gaz": (60, 200, 60),
          "sag": (230, 150, 40), "sol": (40, 160, 250)}
SAFE_CLASS = "fren"
ASSET_URL = ("https://storage.googleapis.com/mediapipe-models/"
             "hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task")


def parse_args():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="HandPilot CNN canli kamera testi")
    parser.add_argument("--camera", type=int, default=0, help="Kamera indeksi")
    parser.add_argument("--model", type=Path,
                        default=here / "handpilot_mobilenet_v3_small.keras")
    parser.add_argument("--asset", type=Path,
                        default=here / "assets" / "hand_landmarker.task")
    parser.add_argument("--threshold", type=float, default=0.70,
                        help="Bu olasiligin altinda guvenli durus (fren)")
    parser.add_argument("--smooth", type=int, default=5,
                        help="Olasilik ortalama pencere uzunlugu")
    parser.add_argument("--wait", action="store_true",
                        help="Kamera baglanana kadar bekleyip otomatik basla")
    parser.add_argument("--snapshot-dir", type=Path,
                        default=here / "canli_kayit")
    return parser.parse_args()


def ensure_asset(path):
    if path.exists() and path.stat().st_size > 1_000_000:
        return path
    path.parent.mkdir(parents=True, exist_ok=True)
    print("MediaPipe el modeli indiriliyor:", ASSET_URL)
    tmp = path.with_name(path.name + ".tmp")
    urllib.request.urlretrieve(ASSET_URL, tmp)
    if tmp.stat().st_size < 1_000_000:
        tmp.unlink(missing_ok=True)
        raise RuntimeError("MediaPipe model dosyasi indirilemedi.")
    tmp.replace(path)
    print("MediaPipe el modeli hazir:", path)
    return path


def load_model(path):
    os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
    from tensorflow import keras
    if not path.exists():
        raise FileNotFoundError("Model bulunamadi: " + str(path))
    model = keras.models.load_model(path, compile=False)
    model(np.zeros((1, 160, 160, 3), dtype=np.uint8), training=False)
    return model


def open_camera(index):
    if sys.platform.startswith("win"):
        backends = [("DSHOW", cv2.CAP_DSHOW), ("MSMF", cv2.CAP_MSMF),
                    ("ANY", cv2.CAP_ANY)]
    elif sys.platform == "darwin":
        backends = [("AVFOUNDATION", cv2.CAP_AVFOUNDATION), ("ANY", cv2.CAP_ANY)]
    else:
        backends = [("V4L2", cv2.CAP_V4L2), ("ANY", cv2.CAP_ANY)]
    for name, backend in backends:
        cap = cv2.VideoCapture(index, backend)
        if not cap.isOpened():
            cap.release()
            continue
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        cap.set(cv2.CAP_PROP_FPS, 30)
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        ok, frame = cap.read()
        if ok and frame is not None:
            print("Kamera %d acildi (%s), %dx%d" %
                  (index, name, frame.shape[1], frame.shape[0]))
            return cap
        cap.release()
    raise RuntimeError(
        "Kamera %d acilamadi. Bu bilgisayar Lenovo LOQ 15IRX9 ve e-shutter "
        "donanimina sahip. Bilgisayarin sag kenarindaki kamera anahtarini "
        "ACIK konuma getirin (kirmizi isaret gorunmemeli). Ardindan kamerayi "
        "kullanan diger uygulamalari kapatip yeniden deneyin. Windows kamera "
        "izni zaten acik ve aygit surucusu saglikli olarak dogrulandi." % index)


class HandCropper:
    def __init__(self, asset, padding=0.30, size=160,
                 detection=0.5, presence=0.5):
        import mediapipe as mp
        from mediapipe.tasks import python
        from mediapipe.tasks.python import vision
        self.mp = mp
        self.vision = vision
        self.connections = vision.HandLandmarksConnections.HAND_CONNECTIONS
        self.padding = padding
        self.size = size
        options = vision.HandLandmarkerOptions(
            base_options=python.BaseOptions(model_asset_path=str(asset)),
            running_mode=vision.RunningMode.IMAGE,
            num_hands=2,
            min_hand_detection_confidence=detection,
            min_hand_presence_confidence=presence)
        self.detector = vision.HandLandmarker.create_from_options(options)

    def process(self, bgr):
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        result = self.detector.detect(self.mp.Image(
            image_format=self.mp.ImageFormat.SRGB, data=rgb))
        if not result.hand_landmarks:
            return None, None, "EL YOK"
        if len(result.hand_landmarks) != 1:
            return None, None, "BIRDEN FAZLA EL"
        hand = result.hand_landmarks[0]
        height, width = rgb.shape[:2]
        pts = np.array([(p.x * width, p.y * height) for p in hand], dtype=np.float32)
        lo, hi = pts.min(0), pts.max(0)
        pad = float(max(hi - lo)) * self.padding
        box = (int(np.floor(lo[0] - pad)), int(np.floor(lo[1] - pad)),
               int(np.ceil(hi[0] + pad)), int(np.ceil(hi[1] + pad)))
        if box[2] <= box[0] or box[3] <= box[1]:
            return None, None, "GECERSIZ ROI"
        roi = ImageOps.pad(Image.fromarray(rgb).crop(box),
                           (self.size, self.size),
                           method=Image.Resampling.BILINEAR, color=(0, 0, 0))
        return np.asarray(roi), (box, hand), ""

    def close(self):
        self.detector.close()


def draw_landmarks(frame, hand, connections):
    height, width = frame.shape[:2]
    points = [(int(p.x * width), int(p.y * height)) for p in hand]
    for edge in connections:
        cv2.line(frame, points[edge.start], points[edge.end], (0, 230, 255), 2)
    for point in points:
        cv2.circle(frame, point, 3, (0, 255, 0), -1)


def draw_panel(frame, command, reason, probabilities, fps):
    height, width = frame.shape[:2]
    color = COLORS[command]
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (width, 92), (20, 20, 20), -1)
    cv2.rectangle(overlay, (0, height - 132), (width, height), (20, 20, 20), -1)
    cv2.addWeighted(overlay, 0.65, frame, 0.35, 0, frame)
    cv2.putText(frame, "HandPilot Canli Test  FPS %.1f" % fps, (16, 28),
                cv2.FONT_HERSHEY_SIMPLEX, 0.65, (230, 230, 230), 2)
    cv2.putText(frame, TITLES[command], (16, 74),
                cv2.FONT_HERSHEY_SIMPLEX, 1.7, color, 4)
    if reason:
        text = "GUVENLI DURUS: " + reason
        (text_width, _), _ = cv2.getTextSize(
            text, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 2)
        cv2.putText(frame, text, (width - text_width - 16, 28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 200, 255), 2)
    cv2.putText(frame, "Ayna acik | Q: cikis | S: goruntu kaydet",
                (16, height - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                (200, 200, 200), 1)
    if probabilities is None:
        return
    base = height - 116
    for index, name in enumerate(CLASSES):
        value = float(probabilities[index])
        y = base + index * 25
        cv2.putText(frame, name.upper(), (16, y + 16),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (220, 220, 220), 1)
        cv2.rectangle(frame, (90, y), (290, y + 16), (80, 80, 80), 1)
        cv2.rectangle(frame, (90, y),
                      (90 + int(200 * min(max(value, 0.0), 1.0)), y + 16),
                      COLORS[name], -1)
        cv2.putText(frame, "%5.1f%%" % (value * 100), (300, y + 14),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (220, 220, 220), 1)


def main():
    args = parse_args()
    asset = ensure_asset(args.asset)
    print("Model yukleniyor:", args.model)
    model = load_model(args.model)
    cropper = HandCropper(asset)
    print("Sinif sirasi: 0=fren, 1=gaz, 2=sag, 3=sol")
    print("Guven esigi: %.2f | Yumusatma: %d kare" %
          (args.threshold, max(1, args.smooth)))
    waiting = False
    while True:
        try:
            camera = open_camera(args.camera)
            break
        except RuntimeError as error:
            if not args.wait:
                raise
            if not waiting:
                print(error)
                waiting = True
            print("Kamera bekleniyor... Baglayinca otomatik baslayacak. "
                  "Cikis: Ctrl+C")
            time.sleep(5)
    history = deque(maxlen=max(1, args.smooth))
    window = "HandPilot - Canli Test"
    cv2.namedWindow(window, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window, 960, 720)
    fps, last = 0.0, time.perf_counter()
    last_message = None
    try:
        while True:
            ok, raw = camera.read()
            if not ok or raw is None:
                print("Kameradan kare okunamadi; cikiliyor.")
                break
            frame = cv2.flip(raw, 1)
            roi, detail, problem = cropper.process(frame)
            probabilities = None
            reason = problem
            if roi is not None:
                probabilities = model(np.expand_dims(roi, 0),
                                      training=False).numpy()[0]
                history.append(probabilities)
                smoothed = np.mean(history, axis=0)
                index = int(smoothed.argmax())
                confidence = float(smoothed[index])
                if confidence < args.threshold:
                    command = SAFE_CLASS
                    reason = "GUVEN DUSUK (%.2f)" % confidence
                else:
                    command = CLASSES[index]
                box, hand = detail
                color = COLORS[command]
                cv2.rectangle(frame, (box[0], box[1]), (box[2], box[3]),
                              color, 2)
                draw_landmarks(frame, hand, cropper.connections)
            else:
                history.clear()
                command = SAFE_CLASS
            now = time.perf_counter()
            instant = 1.0 / max(now - last, 1e-6)
            fps = instant if fps == 0.0 else 0.9 * fps + 0.1 * instant
            last = now
            draw_panel(frame, command, reason, probabilities, fps)
            message = "%s | %s" % (TITLES[command], reason or "guven yuksek")
            if message != last_message:
                print(message)
                last_message = message
            cv2.imshow(window, frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (27, ord("q")):
                break
            if key == ord("s"):
                args.snapshot_dir.mkdir(parents=True, exist_ok=True)
                name = time.strftime("canli_%Y%m%d_%H%M%S.png")
                path = args.snapshot_dir / name
                cv2.imwrite(str(path), frame)
                print("Goruntu kaydedildi:", path)
            if cv2.getWindowProperty(window, cv2.WND_PROP_VISIBLE) < 1:
                break
    finally:
        camera.release()
        cropper.close()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, FileNotFoundError) as error:
        print("HATA:", error)
        sys.exit(1)
