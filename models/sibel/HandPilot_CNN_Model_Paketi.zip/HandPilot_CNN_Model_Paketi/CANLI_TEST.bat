@echo off
chcp 65001 >nul
title HandPilot Canli Test
cd /d "%~dp0"
if not exist "%~dp0.venv\Scripts\python.exe" (
  echo HATA: Yerel Python ortami bulunamadi.
  echo Once KURULUM.bat dosyasini calistirin.
  pause
  exit /b 1
)
"%~dp0.venv\Scripts\python.exe" "%~dp0canli_test.py" --camera 0 --wait %*
if errorlevel 1 pause
